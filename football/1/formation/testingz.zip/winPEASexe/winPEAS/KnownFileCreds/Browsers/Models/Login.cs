﻿namespace winPEAS.KnownFileCreds.Browsers.Models
{
    class Login
    {
        public string action_url { get; set; }
        public string username_value { get; set; }
        public byte[] password_value { get; set; }
    }
}
