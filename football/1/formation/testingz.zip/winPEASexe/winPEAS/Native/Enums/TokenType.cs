﻿using System;

namespace winPEAS.Native.Enums
{
    [Serializable]
    public enum TokenType
    {
        TokenImpersonation = 2,
        TokenPrimary = 1
    }
}
