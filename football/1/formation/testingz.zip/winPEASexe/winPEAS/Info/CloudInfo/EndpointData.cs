﻿namespace winPEAS.Info.CloudInfo
{
    internal class EndpointData
    {
        public string EndpointName { get; set; }
        public string Data { get; set; }

        public bool IsAttackVector { get; set; }
    }
}
