﻿namespace winPEAS.Info.SystemInfo.AuditPolicies
{
    internal enum AuditType
    {
        Success = 1,
        Failure = 2,
        SuccessAndFailure = 3
    }
}
